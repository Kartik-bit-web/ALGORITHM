function linearL(arr, val, size){
    if(size == 0){
        return -1
        }
    else if(arr[size -1] == val){
        return arr[size-1]
        }
    else{
        return linearL(arr, val, size-1)
        }
    }

const arr = [1,2,3,4,5,6,7,8,9,10]
const val = 6
const size = arr.length

result = linearL(arr, val, size)
console.log('Using Recussive: ', result)


function linear(arr, val, size){
    for(let i=0; i < size; i++){
        if(arr[i] == val){
            return arr[i]
        }
    }
    return -1
}

result2 = linear(arr, val, size)
console.log('Using Itration: ',result2)
