function binary(arr, val, start, size){
    if(start > size){
       
        return 'Something wrong';
    }
    
    else{ 
        mided = start+(size -1)/2
        mid = mided.toFixed()

        if (val == arr[mid]){
            return mid;
        }
        
        else if(arr[mid] > val){
            return binary(arr, val, start, size-1);
        }
        
        else {
            return binary(arr, val, start+1, size);
        }
    }
}

const arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const val = 5;
const size = arr.length;

result = binary(arr, val, 0, size)
console.log('Using Recussive: ', result)


function binaryI(arr, val, start, size){
    while (start < size){
          mided = start+(size -1)/2
          mid = mided.toFixed()
          
          if(arr[mid] == mid){
              return mid
          }
          
          else if(arr[mid] > val){
              size = mid -1
              return 'Found Less'                          
          }
          
          else{
              start = mid +1
              return 'Found Upper'            
          }
    }
    
    return -1
}

result2 = binaryI(arr, val, 0, size)
console.log('Using Itration: ',result2)
