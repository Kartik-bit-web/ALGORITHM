function ternary(arr, val, start, size){
    if(size > 0){
        
        let mided1 = start + (size -1)/3
        let mid1 = parseInt(mided1);
        
        let mided2 = size - (size -1)/3
        let mid2 = parseInt(mided2);
        
        if(arr[mid1] == val){
            return mid1
        }
        if(arr[mid2] == val){
            return mid2
        }
        
        if(arr[mid1] > val){
            return ternary(arr, val, start, mid1-1)
        }
        
        else if(arr[mid2] < val){
            return ternary(arr, val, mid2+1, size-1)
        }
        
        else{
            return ternary(arr, val, mid1+1, mid2-1)
            }
    }
    
    return -1
}

const arr= [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const val = 6;
const size = arr.length;

result = ternary(arr, val, 0, size);
console.log(result)
console.log('9')

