#Binary Search In Recussive Method
def binary(arr, val, start, size):
    if size < 0:
        return False
    
    else: 
        mid = (start + size) //2
        
        if arr[mid] == val:
            return mid
        
        elif val > arr[mid]:
            return binary(arr, val, mid+1, size)
         
        else:
            return binary(arr, val, start, size-1)

arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
val = 10
size = len(arr)

result = binary(arr, val, 0, size-1)
print('Using Recusive: ', result)

#Binary Search In Itration Method
def binary2(arr, val, start, size):
    while start <= size:
        mid = start + (size - 1) //2
        
        if arr[mid] == val:
            return mid
            
        elif val > arr[mid]:
            start = mid + 1
            return 'found in plus'

        else:
            size = mid - 1
            return 'found in minus'

            
arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
val = 10
size = len(arr)
result2 = binary2(arr, val, 0, size-1)
print('Using Itration: ',result2)
