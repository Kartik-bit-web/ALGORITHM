#Recussive Method In Linear Search
def linear(arr, val, size):
    if size == 0:
        return -1
        
    elif arr[size-1] == val:
        return arr[size-1]
        
    else:
        return linear(arr, val, size -1)
arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
val = 6
size = len(arr)

result = linear(arr, val, size)
print('Using Recussive: ', result)



#Iteration Method In Linear Search
def linear2(arr, val, size):
    for i in range(0, size):
        if arr[i] == val:
            return arr[i]
    return -1
    
arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
val = 6
size = len(arr)

result2 = linear2(arr, val, size)
print('Using Itration: ', result2)
