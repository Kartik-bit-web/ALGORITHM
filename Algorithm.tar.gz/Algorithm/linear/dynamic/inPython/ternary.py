#Ternary Algorithm Method Using Python :-

def ternary(arr, val, start, size):
    if size > 0:
        
        mid1 = start + (size - 1)//3
        mid2 = size - (size - 1)//3
       
        if arr[mid1] == val:
            return mid1
        if arr[mid2] == val:
            return mid2
        
        if val < arr[mid1]:
            return ternary(arr, val, start, mid1-1)
        elif val > arr[mid2]:
            return ternary(arr, val, mid2+1, size)
        
        else:
            return ternary(arr, val, mid1 + 1, mid2-1)
            
    return -1
    
arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
val = 6
size = len(arr)       
result = ternary(arr, val, 0, size)
print(result)
