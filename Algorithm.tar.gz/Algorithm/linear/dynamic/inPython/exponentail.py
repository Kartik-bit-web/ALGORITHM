def binary(arr, val, start, size):
    if start <= size:
        mid = start + ((size-1) - start) //2
        if arr[mid] == val:
            return mid
            
        if arr[mid] > val:
            return binary(arr, val, start, mid-1)
        else:
            return binary(arr, val, mid+1, size)       
            
    return -1

def expo(arr, val,start, size):
    if size-1 < start:
        return -1
    i = 1
    while i < size-start:
        if arr[i] < val:    
            i = i * 2
        else:
            break
    return binary(arr, val, i//2, i )

arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
val = 11
size = len(arr)

result = expo(arr, val, 1, size)
print(result) 
